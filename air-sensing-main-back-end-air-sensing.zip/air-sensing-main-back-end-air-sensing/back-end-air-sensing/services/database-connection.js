require('dotenv').config();
const mongoString = `${process.env.DATABASE_URL}:${process.env.DATABASE_PORT}`; //url and port from .env file
const mongoose = require('mongoose');
mongoose.connect(mongoString);
const database = mongoose.connection;

database.on('error', (error) => {
  console.log(`⚡️[server]: ${error}`)
})

database.once('connected', () => {
  console.log(`⚡️[server]: Connected to Database ${mongoString}`);
})