require('dotenv').config();
const mqtt = require('mqtt');
const Model = require('../models/record.js');

// MQTT broker URL and port
const brokerUrl = process.env.MQTT_URL; // Replace with your MQTT broker's URL or IP address
const brokerPort = process.env.MQTT_PORT; // Default MQTT port
const topic = 'sensor-data'; // Replace with the topic you want to subscribe to

// Connect to the MQTT broker
const client = mqtt.connect(`${brokerUrl}:${brokerPort}`);

client.on('connect', () => {
  console.log(`⚡️[server]: Connected to MQTT broker ${brokerUrl}:${brokerPort}`);

  // Subscribe to the specified topic
  client.subscribe(topic, (err) => {
    if (!err) {
      console.log(`⚡️[server]: Subscribed to topic: ${topic}`);
    } else {
      console.error('⚡️[server]: Subscription error:', err);
    }
  });
});

// Handle incoming messages
client.on('message', async (receivedTopic, message) => {
  const newMessage = JSON.parse(message.toString());

  //todo: verify if data is correctly formatted

  newMessage.sensors.forEach(async (sensor) => { // Loop through each sensor in the message
    const data = new Model({
      metadata: {
        timestamp: sensor.timestamp,
        bridge_id: newMessage.bridge.id,
        sensor_id: sensor.id,
        floor: parseInt(sensor.floor),
        position: sensor.position
      },
      sensor: {
        type: sensor.type,
        value: parseFloat(sensor.value),
        unit: sensor.unit,
      }
    })

    try {
      const dataToSave = await data.save();
      // console.log(`data from "${newMessage.bridge.id}" inserted`);
    }
    catch (error) {
      console.log({ message: error.message });
    }
  });
});

// Handle disconnection
client.on('close', () => {
  console.log('⚡️[server]: Disconnected from MQTT broker');
});

// Handle errors
client.on('error', (error) => {
  console.error('⚡️[server]: MQTT error:', error);
});