const mongoose = require('mongoose');

const recordSchema = new mongoose.Schema({
    metadata: {
        timestamp: {
            required: true,
            type: Date
        },
        bridge_id: {
            required: true,
            type: String
        },
        sensor_id: {
            required: true,
            type: String
        },
        floor: {
            required: false,
            type: String
        },
        position: {
            required: false,
            type: Object
        }
    },
    sensor: {
        type: {
            required: true,
            type: String
        },
        value: {
            required: true,
            type: Number
        },
        unit: {
            required: true,
            type: String
        }
    }
})

module.exports = mongoose.model('records', recordSchema)