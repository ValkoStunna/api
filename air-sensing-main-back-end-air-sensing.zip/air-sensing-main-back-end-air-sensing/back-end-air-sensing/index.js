require('./services/database-connection')
require('./services/mqtt-client');
require('./services/rest-api');