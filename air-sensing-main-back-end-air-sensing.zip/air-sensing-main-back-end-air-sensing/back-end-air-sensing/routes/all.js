const express = require('express');
const router = express.Router()
module.exports = router;
const Model = require('../models/record.js');


// Get Method
router.get('/:variableParam', async (req, res) => {
  const variableParam = req.params.variableParam;
  const limitReq = req.query.limit;
  const offsetReq = req.query.offset;
  const sensorId = req.query.sensorId;
  const bridgeId = req.query.bridgeId;
  const position = req.query.position;
  const timestamp = req.query.timestamp;
  const value = req.query.value;
  const includeMetadata = req.query.includeMetadata;
  const floor = req.query.floor;


  // Perform processing based on the query parameters
  let searchQuery = {};
  let limit = 100;
  let offset = 0;
  let include = "";
  if (limitReq) {
    limit = parseInt(limitReq);
  }
  if (offsetReq) {
    offset = parseInt(offsetReq);
  }
  if (variableParam != "all") {
    searchQuery['sensor.type'] = variableParam;
  }
  if (sensorId) {
    searchQuery['metadata.sensor_id'] = sensorId;
  }
  if (bridgeId) {
    searchQuery['metadata.bridge_id'] = bridgeId;
  }
  if (timestamp) {
    console.log(timestamp);
    if (timestamp.slice(0,1) == '>') {
      searchQuery['metadata.timestamp'] = {$gt: timestamp.substr(1, timestamp.length - 1)}; //greater than
    } else if (timestamp.slice(0, 1) == '<') {
      searchQuery['metadata.timestamp'] = {$lt: timestamp.substr(1, timestamp.length - 1)}; //less than
    }
  }
  if (value && variableParam != "all") {
    if (value.slice(0, 1) == '>') {
      searchQuery['sensor.value'] = {$gt: value.substr(1, value.length - 1)}; //greater than
    } else if (value.slice(0, 1) == '<') {
      searchQuery['sensor.value'] = {$lt: value.substr(1, value.length - 1)}; //less than
    }
  }
  if (includeMetadata) {
    if (includeMetadata == 'false' || includeMetadata == '0') {
      include += '-metadata';
    }
  }
  if (floor) {
    searchQuery['metadata.floor'] = floor;
  }
  if (floor && position) {
    searchQuery['metadata.floor'] = floor;
    // searchQuery['metadata.location'] = location;
    const low = position[0].split(';');
    const high = position[1].split(';');
    searchQuery['metadata.position.x'] = {$gt: parseInt(low[0]), $lt: parseInt(high[0])}; // filters within xMin and xMax
    searchQuery['metadata.position.y'] = {$gt: parseInt(low[1]), $lt: parseInt(high[1])}; // filter within yMin and yMax
  }

  // console.log(searchQuery);

  try{
      const data = await Model.find(searchQuery, include).skip(offset).limit(limit);
      res.json(data)
  }
  catch(error){
      res.status(500).json({message: error.message})
  }
})